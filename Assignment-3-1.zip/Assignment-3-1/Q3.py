def add_many(x, elem, lst):
    count = lst.count(x)
    lst.extend([elem] * count)


user_input = input("Enter a list of values (separated by commas): ")
lst = user_input.split(',')

x = input("Enter the value to count: ")
elem = input("Enter the element to add: ")


add_many(x, elem, lst)
print(lst)
