def crte_2d_arr(rows, columns):
    return [['-' for _ in range(columns)] for _ in range(rows)]

def get_user_input():
    rows = int(input("Enter the number of rows: "))
    columns = int(input("Enter the number of columns: "))
    return rows, columns

rows, columns = get_user_input()
result = crte_2d_arr(rows, columns)
print(result)
