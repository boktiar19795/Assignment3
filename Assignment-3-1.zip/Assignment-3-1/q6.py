def fltn(_2d_list):
    flat_list = []
    for element in _2d_list:
        if type(element) is list:
            flat_list.extend(fltn(element))
        else:
            flat_list.append(element)
    return flat_list


# Prompt the user for input
user_input = input("Enter a nested list: ")

# Convert the user input to a nested list
try:
    nested_list = eval(user_input)
    flattened_list = fltn(nested_list)
    print("Flattened list:", flattened_list)
except:
    print("Invalid input. Please enter a valid nested list.")
