import json

def chk_elm(lst, n):

    for element in lst:
        if isinstance(element, list):
            if chk_elm(element, n):
                return True
        elif element == n or str(element) == str(n):
            return True
    return False

lst_input = input("Enter the list (comma-separated values): ")
try:
    a = json.loads(lst_input)
except json.JSONDecodeError:
    print("Invalid list format. Please provide a valid JSON list.")
    exit()

n = input("Enter the element to check: ")

print(chk_elm(a, n))
