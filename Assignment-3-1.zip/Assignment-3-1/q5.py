def mrg(ls1, ls2):
    merged_lst = []

    if len(ls1) == 0:
        return ls2
    if len(ls2) == 0:
        return ls1

    if isinstance(ls1[0], str) and isinstance(ls2[0], str):
        if ls1[0] <= ls2[0]:
            merged_lst.append(ls1[0])
            merged_lst.extend(mrg(ls1[1:], ls2))
        else:
            merged_lst.append(ls2[0])
            merged_lst.extend(mrg(ls1, ls2[1:]))
    elif isinstance(ls1[0], (int, float)) and isinstance(ls2[0], (int, float)):
        if ls1[0] <= ls2[0]:
            merged_lst.append(ls1[0])
            merged_lst.extend(mrg(ls1[1:], ls2))
        else:
            merged_lst.append(ls2[0])
            merged_lst.extend(mrg(ls1, ls2[1:]))
    else:
        raise ValueError("Cannot compare elements of different types")

    return merged_lst

# Accept user input
ls1_input = input("Enter the first sorted list (separated by commas): ")
ls1 = ls1_input.split(',')

ls2_input = input("Enter the second sorted list (separated by commas): ")
ls2 = ls2_input.split(',')

# Convert numbers if possible
ls1 = [float(x) if '.' in x else int(x) if x.isdigit() else x for x in ls1]
ls2 = [float(x) if '.' in x else int(x) if x.isdigit() else x for x in ls2]

# Call the mrg function and print the result
print(mrg(ls1, ls2))
