from operator import add, sub, mul

def fld(lst, g, m):
    if len(lst) == 0:
        return m
    else:
        return g(fld(lst[1:], g, m), lst[0])

def get_user_input():
    lst = []
    while True:
        num = input("Enter a number (or 'Done' to input number): ")
        if num == 'Done':
            break
        try:
            lst.append(float(num))
        except ValueError:
            print("Invalid Input, Enter Number")
    return lst

choice = input("Enter the operation ((+) for add, (-) for subtraction, (*) for multiplication): ")

if choice == '+':
    g = add
    m = 0
elif choice == '-':
    g = sub
    m = 0
elif choice == '*':
    g = mul
    m = 1
else:
    print("Invalid choice!")
    exit()

lst = get_user_input()
result = fld(lst, g, m)
print("Result:", result)
