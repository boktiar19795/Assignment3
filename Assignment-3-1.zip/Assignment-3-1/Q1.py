def mk_wd(balance):
    def withdraw(amount):
        nonlocal balance
        if amount <= balance:
            balance -= amount
            return balance
        else:
            return 'Insufficient funds'

    return withdraw

initial_balance = None
while initial_balance is None:
    try:
        initial_balance = float(input("Enter the initial balance: "))
        if initial_balance < 0:
            print("Invalid input. Initial balance cannot be negative.")
            initial_balance = None
    except ValueError:
        print("Invalid input. Please enter a valid number.")

rem = mk_wd(initial_balance)

while True:
    try:
        amount = float(input("Enter the withdrawal amount (or 0 to exit): "))
        if amount == 0:
            break
        elif amount < 0:
            print("Invalid input. Withdrawal amount cannot be negative.")
        else:
            remaining_balance = rem(amount)
            print(f"Remaining balance: {remaining_balance}")
    except ValueError:
        print("Invalid input. Please enter a valid number.")

print("Program terminated.")
