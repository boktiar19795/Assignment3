def f(suits, numbers):
    suit_num = []
    if len(suits) == 0 or len(numbers) == 0:
        return suit_num
    else:
        for i in range(len(suits)):
            for j in range(len(numbers)):
                suit_num.append([suits[i], int(numbers[j])])
        return suit_num

def get_user_input():
    suits = input("Enter a list of suits (separated by commas): ").split(',')
    numbers = input("Enter a list of numbers (separated by commas): ").split(',')
    return suits, numbers

suits, numbers = get_user_input()
result = f(suits, numbers)
print(result)
