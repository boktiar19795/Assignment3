def rm_all(elements, lst):
    answer = [i for i in lst if i not in elements]
    return answer

user_input = input("Enter a list of numbers or strings (separated by commas): ")
x = user_input.split(',')

elements_input = input("Enter the elements to remove (separated by commas): ")
elements = elements_input.split(',')

result = rm_all(elements, x)
print(result)
