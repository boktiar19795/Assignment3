def sym(l):
    if len(l) <= 1:
        return True
    else:
        return l[0] == l[-1] and sym(l[1:-1])

def get_user_input():
    lst = input("Enter a list of elements (separated by commas): ").split(",")
    return lst

lst = get_user_input()
result = sym(lst)
print("is it Symmetric?:", result)
